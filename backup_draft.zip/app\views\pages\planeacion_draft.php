<?php
// planeacion_draft.php
// Este archivo es el Modo Draft y el Motor de Horarios para el próximo cuatrimestre.
$carreraId = $_SESSION['carrera_id'] ?? 1; // Ajustar según Auth
?>

<!-- Estilos para la Modal Fullscreen Módulo de Planeación -->
<style>
.fullscreen-modal {
    display: none;
    position: fixed;
    top: 0; left: 0; right: 0; bottom: 0;
    width: 100%; height: 100%;
    background-color: #f8f9fa;
    z-index: 9999;
    overflow-y: auto;
}
.fullscreen-modal.active {
    display: flex;
    flex-direction: column;
}
.modal-header-custom {
    padding: 1rem 2rem;
    background-color: #ffffff;
    border-bottom: 1px solid #dee2e6;
    display: flex;
    justify-content: space-between;
    align-items: center;
    box-shadow: 0 2px 4px rgba(0,0,0,0.05);
}
.modal-body-custom {
    padding: 2rem;
    flex-grow: 1;
    max-width: 900px;
    margin: 0 auto;
    width: 100%;
}
.step-container { display: none; }
.step-container.active { display: block; animation: fadeIn 0.3s; }
@keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
</style>

<div class="container-fluid mb-4 mt-4">
    <div class="card shadow-sm border-0">
        <div class="card-body text-center py-5">
            <i class="fas fa-calendar-alt fa-3x text-primary mb-3"></i>
            <h3>Planeación Prospectiva (Siguiente Cuatrimestre)</h3>
            <p class="text-muted max-w-50 mx-auto">
                Accede al entorno de pruebas (Sandbox) para simular el horario del próximo ciclo. Aquí podrás definir transiciones de grupos, docentes activos y ejecutar el Motor Generador para ver la nómina sin afectar la base de datos de producción actual.
            </p>
            <button class="btn btn-primary btn-lg mt-3" onclick="openDraftModal()">
                <i class="fas fa-magic me-2"></i> Abrir Modo Draft
            </button>
        </div>
    </div>
</div>

<!-- FULLSCREEN MODAL -->
<div id="draftModal" class="fullscreen-modal">
    <div class="modal-header-custom">
        <div>
            <h4 class="mb-0 text-primary"><i class="fas fa-vial me-2"></i> Sandbox: Planeación de Horarios</h4>
            <small class="text-muted">Simulador interactivo</small>
        </div>
        <button class="btn btn-outline-danger" onclick="closeDraftModal()">
            <i class="fas fa-times"></i> Cerrar Draft
        </button>
    </div>

    <div class="modal-body-custom">
        <!-- STEPS HEADER -->
        <div class="d-flex justify-content-between mb-5 border-bottom pb-3 text-center">
            <div id="step-btn-1" class="text-primary fw-bold"><i class="fas fa-users mb-1 d-block"></i> 1. Grupos</div>
            <div id="step-btn-2" class="text-secondary"><i class="fas fa-chalkboard-teacher mb-1 d-block"></i> 2. Docentes</div>
            <div id="step-btn-3" class="text-secondary"><i class="fas fa-cogs mb-1 d-block"></i> 3. Motor (Simulacro)</div>
            <div id="step-btn-4" class="text-secondary"><i class="fas fa-file-invoice-dollar mb-1 d-block"></i> 4. Nómina</div>
        </div>

        <!-- STEP 1: GRUPOS -->
        <div id="step-1" class="step-container active">
            <h5>Paso 1: Transición de Grupos</h5>
            <p class="text-muted">Define los grupos que pasan al siguiente cuatrimestre y cuáles desaparecen.</p>
            <div class="card shadow-sm">
                <div class="card-body">
                    <p class="text-center text-muted col-12 py-4">Tabla de Transición Interactiva (Datos Demo)</p>
                    <table class="table table-hover">
                        <thead><tr><th>Grupo Actual</th><th>Acción</th><th>Nuevo Grupo</th></tr></thead>
                        <tbody id="groupsTransitionTable">
                            <tr>
                                <td>8A VFx</td>
                                <td>
                                    <select class="form-select form-select-sm">
                                        <option>Promover (Avanza de cuatri)</option>
                                        <option>Eliminar (Baja/Graduación)</option>
                                    </select>
                                </td>
                                <td><input type="text" class="form-control form-control-sm" value="9A VFx"></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="text-end mt-4"><button class="btn btn-primary" onclick="goToStep(2)">Siguiente <i class="fas fa-arrow-right"></i></button></div>
        </div>

        <!-- STEP 2: DOCENTES -->
        <div id="step-2" class="step-container">
            <h5>Paso 2: Disponibilidad Docente</h5>
            <p class="text-muted">Selecciona los maestros activos para el próximo cuatrimestre.</p>
            <div class="card shadow-sm">
                <div class="card-body" id="teachersListDiv">
                    <!-- Demo info -->
                    <div class="form-check form-switch mb-2">
                        <input class="form-check-input" type="checkbox" checked id="prof1">
                        <label class="form-check-label fw-bold" for="prof1">Prof. Juan Pérez</label>
                    </div>
                </div>
            </div>
            <div class="d-flex justify-content-between mt-4">
                <button class="btn btn-secondary" onclick="goToStep(1)"><i class="fas fa-arrow-left"></i> Anterior</button>
                <button class="btn btn-primary" onclick="goToStep(3)">Siguiente <i class="fas fa-arrow-right"></i></button>
            </div>
        </div>

        <!-- STEP 3: MOTOR -->
        <div id="step-3" class="step-container text-center py-5">
            <i class="fas fa-microchip fa-4x text-primary mb-3"></i>
            <h4>Motor de Generación (Local)</h4>
            <p class="text-muted mx-auto" style="max-width: 500px;">
                Se ejecutarán los algoritmos para asignar aulas fijas, evitar traslapes (Hard Constraints), agrupar horas (Soft Constraints: evitar huecos) e incluir horas de descarga, buscando un score de Cero Horas Muertas.
            </p>
            <button class="btn btn-success btn-lg mt-3" id="runEngineBtn" onclick="runEngine()">
                <i class="fas fa-play"></i> Ejecutar Algoritmo (Simulacro)
            </button>
            
            <div id="engineSpinner" class="mt-4 d-none">
                <div class="spinner-border text-primary" role="status"></div>
                <p class="mt-2 text-primary fw-bold" id="engineLog">Resolviendo restricciones...</p>
            </div>
        </div>

        <!-- STEP 4: REPORTE -->
        <div id="step-4" class="step-container">
            <h5 class="text-success"><i class="fas fa-check-circle"></i> Horario Generado Exitosamente</h5>
            <h6 class="mt-4 fw-bold">Reporte de Carga Horaria para Nómina/Contratos</h6>
            <div class="table-responsive">
                <table class="table table-bordered bg-white shadow-sm mt-2">
                    <thead class="bg-light">
                        <tr><th>Docente</th><th class="text-end">Horas Clase</th><th class="text-end">Horas Descarga</th><th class="text-end text-primary">Total a Pagar</th></tr>
                    </thead>
                    <tbody id="reportTableBody">
                    </tbody>
                </table>
            </div>

            <div class="alert alert-info mt-4 d-flex justify-content-between align-items-center">
                <div>
                    <strong><i class="fas fa-info-circle"></i> Confirmar y Publicar</strong><br>
                    Esto trasladará el horario draft a la tabla de producción, sobrescribirá el cuatrimestre actual y enviará notificaciones a alumnos/docentes.
                </div>
                <button class="btn btn-primary" onclick="publishSchedule()">Publicar Permanentemente</button>
            </div>

            <div class="d-flex justify-content-between mt-4">
                <button class="btn btn-secondary" onclick="goToStep(3)"><i class="fas fa-arrow-left"></i> Modificar Restricciones (Atrás)</button>
            </div>
        </div>
    </div>
</div>

<script>
// UI Lógica
function openDraftModal() { document.getElementById('draftModal').classList.add('active'); goToStep(1); }
function closeDraftModal() { document.getElementById('draftModal').classList.remove('active'); }

function goToStep(stepNumber) {
    document.querySelectorAll('.step-container').forEach(el => el.classList.remove('active'));
    document.getElementById('step-' + stepNumber).classList.add('active');
    
    // Updates headers
    for(let i=1; i<=4; i++) {
        const btn = document.getElementById('step-btn-' + i);
        if(i <= stepNumber) {
            btn.classList.remove('text-secondary');
            btn.classList.add('text-primary', 'fw-bold');
        } else {
            btn.classList.add('text-secondary');
            btn.classList.remove('text-primary', 'fw-bold');
        }
    }
}

function runEngine() {
    document.getElementById('runEngineBtn').disabled = true;
    document.getElementById('engineSpinner').classList.remove('d-none');
    let log = document.getElementById('engineLog');
    
    setTimeout(() => { log.innerText = "Evaluando Hard Constraints (Cero colisiones)..."; }, 800);
    setTimeout(() => { log.innerText = "Optimizando Soft Constraints (Reduciendo horas muertas)..."; }, 1600);
    setTimeout(() => { log.innerText = "Asignando Aulas Fijas y Horas de Descarga..."; }, 2400);
    setTimeout(() => { 
        document.getElementById('engineSpinner').classList.add('d-none');
        document.getElementById('runEngineBtn').disabled = false;
        generateMockReport();
        goToStep(4); 
    }, 3200);
}

function generateMockReport() {
    const tbody = document.getElementById('reportTableBody');
    // Generar datos mock de nómina para validación basándose en el Motor JS.
    let hC = Math.floor(Math.random()*15)+5; let hD = 4;
    tbody.innerHTML = `
        <tr><td>Prof. Juan Pérez</td><td class="text-end">${hC} h</td><td class="text-end text-muted">${hD} h</td><td class="text-end fw-bold text-primary">${hC+hD} h</td></tr>
    `;
}

function publishSchedule() {
    alert("Notificación simulada enviada. El sistema ha borrado el ciclo anterior e insertado los horarios nuevos.");
    closeDraftModal();
}

/**
 * =========================================================
 * CORE: MOTOR DE VALIDACION Y GENERACION - JAVASCRIPT LOCAL
 * =========================================================
 * Contiene Funciones de validación de Colisiones (Hard Constraints).
 */

const ScheduleEngine = {
    // 1. Hard Constraints
    hasTeacherCollision: function(newAsgn, schedule) {
        return schedule.some(a => a.teacherId === newAsgn.teacherId && a.day === newAsgn.day && a.slot === newAsgn.slot);
    },
    hasRoomCollision: function(newAsgn, schedule) {
        return schedule.some(a => a.roomId === newAsgn.roomId && a.day === newAsgn.day && a.slot === newAsgn.slot);
    },
    hasGroupCollision: function(newAsgn, schedule) {
        return schedule.some(a => a.groupId === newAsgn.groupId && a.day === newAsgn.day && a.slot === newAsgn.slot);
    },
    respectsFixedRoom: function(newAsgn, teacher) {
        if(!teacher.preferredRoom) return true;
        return newAsgn.roomId === teacher.preferredRoom;
    },
    validateHardConstraints: function(newAsgn, currentSchedule, teacherData) {
        if(newAsgn.type === 'DESCARGA') {
            return !this.hasTeacherCollision(newAsgn, currentSchedule);
        }
        if(!this.respectsFixedRoom(newAsgn, teacherData)) return {valid:false, reason:"No respeta aula fija."};
        if(this.hasTeacherCollision(newAsgn, currentSchedule)) return {valid:false, reason:"Docente ocupado."};
        if(this.hasRoomCollision(newAsgn, currentSchedule)) return {valid:false, reason:"Aula ocupada."};
        if(this.hasGroupCollision(newAsgn, currentSchedule)) return {valid:false, reason:"Grupo ocupado."};
        return {valid:true};
    },

    // 2. Soft Constraints (Zero Dead Hours)
    calculateDeadHoursForGroup: function(groupId, schedule) {
        let groupClasses = schedule.filter(a => a.groupId === groupId && a.type === 'CLASE');
        let days = ['Lunes','Martes','Miercoles','Jueves','Viernes'];
        let penalty = 0;
        
        days.forEach(day => {
            let times = groupClasses.filter(c => c.day === day).map(c => parseInt(c.slot));
            if(times.length > 1) {
                times.sort((a,b)=>a-b);
                for(let i=0; i<times.length-1; i++) {
                    let diff = times[i+1] - times[i];
                    if(diff > 2) penalty += (diff - 2); // 2 is contiguous block size
                }
            }
        });
        return penalty;
    }
};

</script>
